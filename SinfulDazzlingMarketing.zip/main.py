# Jellybean colour counter
# Author:Kayla S
# Date: Mar 19, 2018

# Takes an image as input and outputs 
# the percentage of each jellybean colour
# in the image 

# First, let's try calculating the percentage of yellow jellybeans and outputting that.

# Import image processing libraries
import time

t0 = time.time()
from PIL import Image

t1 = time.time()

# Load the image
file = Image.open("jelly_beans.jpg")
jbimg = file.load()

# Go through all the pixels in the image
width = file.width
height = file.height

# Initialize a counter
yellow_pixels = 0
red_Pix =0 
blue_Pix=0
Orange_pix=0
t2 = time.time()

for i in range(width):
  for j in range(height):
    
    # If the pixel is yellow ~(255,255,0), add it to a list or counter
    r = jbimg[i,j][0]
    g = jbimg[i,j][1]
    b = jbimg[i,j][2]

    if r > 150 and g > 150 and b < 100:
      yellow_pixels += 1
   
t3 = time.time()


# Calculate the percentage of yellow pixels
# over the total number of pixels in the image 
print(yellow_pixels)
print(width*height)
module_load = t1-t0
image_open_load = t2-t1
loop = t3-t2
entire = t3-t0

# Output the report
percent_yellow = 100*yellow_pixels/(width*height)

report = "There are {:.3f} percent yellow jellybeans.".format(percent_yellow)
timings = "It took {:.2f}s to import PIL, {:.2f}s to load the image, and {:.2f}s to do the loop. All in all it took {:.2f}s.".format(module_load, image_open_load, loop, entire)
print(report)
print(timings)
